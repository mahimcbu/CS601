# mahim.github.io

This is a 7 page portfolio website made for BU software development CS601 course final project.
I built it using the first three assignments and included 7 pages which was recommended by the facilitator to us at the biginning. 

I have validated all page html, css, js, and JSON files using the appropriate validator and linter. Also, I added the NoScript for any situation where the JS can't work.

I have used 4 different media queries in the css to fit the need of all type of screen size. I used flexbox, css grid, animation,
etc. in the css to make the website responsive and !dull.

On the feedback page, I used vue to perform form submission with validation. I also used a bit of vue framework in the education page.
in the same page, I used fetch api to fetch some json objects(my college degrees) and display them after a button is clicked. 

I tried to maintain a consistent navbar, color combination, usage of html 5 syntaxes throughout the 7 page application.

I am a complete beginner here so please don't hesitate to provide your feedback.