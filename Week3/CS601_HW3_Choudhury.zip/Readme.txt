Hi Josh,
This week I created a webpage that uses javascript to do some basic operations.
I created the html page that links the script.js at the end of part of the body. 
It starts off with a pop-up welcome message and then prompts the user for a first.
Click the button and begin adding.
welcome the visitor by name. It then asks for two numbers in two different prompts and then prints out the added value.
I used a function to perform the addition and another one to check for the total value against the number 10.
Then we entered a while loop where based on the prompt response of yes/no we do the same addition function or say bye to the user.
I did not add much css styling as it was optional and wasn't mentioned as something would be considered for going above and beyond. However, I added more checks to the user input for valid inputs.
Lastly, we were not introduced to Dom manipulation yet and I wasn't; t sure so I didn't utilize Dom yet.

