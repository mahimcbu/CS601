Hi Josh, For week2 iteration, I have styled the html based biography website created during the week1 iteration.
I have validated both HTML and CSS codes using the validator link provided in the assignment document. 
I have added another page named "Education" which brings the total pages to 7. Styling all seven with css was a bit challenging and required a lot of time.
I have styled all the important elements using css and made sure all of them use more than one property value as part of going above and beyond. 
You might notice the css style.css link has codes for three different screen sizes in one file. 
I used media-query to break down screen sizes by pixels and then applied different characteristics to  make it easy to understand the differences in the page layout. Additionally, added some text animation using @keyframes after doing some research. 
I struggled with css grid layout a bit before studying it more and decided to apply it in the "work" page and the "Education" page. I beleive I have definitely improved my 
CSS grid understanding.